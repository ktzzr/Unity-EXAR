﻿using System;
using UnityEngine;

public class WaveDance : MonoBehaviour
{

    private const float ZERO_TOLERANCE = 0.0000001f;

    // You can change it to array (AudioPeer[]) and get info 
    // from several AudioSources (ap[0].audioBand[7])
    public AudioPeer ap;

    public int size = 30;
    public GameObject cube;
    public float scaleOfPerlinNoice = 5f;
    public float offset = 2.0f;
    public float heightScale = 4.0f;
    public float WaveSpeed = 0.2f;
    public Gradient gr;
    public float ColorAudioPart = 0.25f;

    [Tooltip("Use it to scale all wave")]
    public Vector3 overallScale = Vector3.one;

    [Tooltip("Space between blocks")]
    public Vector3 overallOffset = Vector3.zero;

    [Tooltip("Resize only prefab and doesnot move it to stick tougether")]
    public bool isPrefabScaleOnly = false;

    private MeshRenderer[] mr;
    private Transform[] tr;
    private Vector3[] startPos;
    private float timeTicks = 0;
    private float LengthX = 0;
    private float LengthZ = 0;
    private Transform pTr;
    private bool isBuilded = false;

    float MaxH = 0;
    float MinH = 0;



    void Start()
    {

        if (ap == null)
        {
            //You can manually set it. But if not - script will take first found on scene.
            ap = GameObject.FindObjectOfType<AudioPeer>();
        }

        Array.Resize(ref mr, size * size + 1);
        Array.Resize(ref tr, size * size + 1);
        Array.Resize(ref startPos, size * size + 1);

        pTr = GetComponent<Transform>();

        for (int x = 0; x < size; ++x)
        {
            for (int z = 0; z < size; ++z)
            {
                var coordX = (pTr.position.x + x);
                var coordZ = (pTr.position.z + z);

                var c = Instantiate(cube, new Vector3(coordX, pTr.position.y, coordZ), Quaternion.identity);

                mr[x * size + z] = c.GetComponent<MeshRenderer>();
                tr[x * size + z] = c.GetComponent<Transform>();
                startPos[x * size + z] = tr[x * size + z].position;
                tr[x * size + z].localScale = overallScale;
                tr[x * size + z].parent = pTr;
            }
        }

        isBuilded = true;
    }



    void Update()
    {
        if (!isBuilded) return;

        // You can choose two case of behaviour when scale == 0 (to prevent division by Zero)
        // Choose and un-comment one of them
        if (scaleOfPerlinNoice == 0)
        {
            //return;          // 1. Stop wave
            scaleOfPerlinNoice = ZERO_TOLERANCE; //2. Slightly move wave
        }

        // Speed connected here. You always can use just Time.timeSinceLevelLoad instead of Mathf.Max() for constant speed
        timeTicks = timeTicks + Mathf.Max(ap._audioBand[6], ap._audioBand[7], ZERO_TOLERANCE) * WaveSpeed;
        for (int i = 0; i < tr.Length - 1; ++i)
        {

            //Apply scale to every cube. You can connect it to music channel.
            tr[i].localScale = overallScale;

            float pX = (tr[i].position.x / scaleOfPerlinNoice) + timeTicks + offset;
            float pZ = (tr[i].position.z / scaleOfPerlinNoice) + timeTicks + offset;

            // Generation based on Perlin Noise
            float height = pTr.position.y + Mathf.PerlinNoise(pX, pZ) * heightScale;

            if (isPrefabScaleOnly)
            {
                tr[i].position = new Vector3(startPos[i].x, height, startPos[i].z);
            }
            else
            {
                tr[i].position = new Vector3(startPos[i].x * (overallScale.x + overallOffset.x),
                                             height,
                                             startPos[i].z * (overallScale.z + overallOffset.z));
            }


            // color connected here
            float colorValue = Mathf.Abs(heightScale) - ap._audioBandBuffers[1] * Mathf.Abs(heightScale) * ColorAudioPart;
            if (colorValue == 0) colorValue = ZERO_TOLERANCE;

            //pTr.position.y subtraction for free moving witout color glitches by Y.
            mr[i].material.SetColor("_Color", gr.Evaluate(Mathf.Abs(height - pTr.position.y) / colorValue));
        }
    }

}
