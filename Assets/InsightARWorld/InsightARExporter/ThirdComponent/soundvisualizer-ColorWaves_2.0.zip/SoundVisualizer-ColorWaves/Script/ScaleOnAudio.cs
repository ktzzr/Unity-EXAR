﻿using UnityEngine;

public class ScaleOnAudio : MonoBehaviour
{

    public AudioPeer ap;

    private Transform _tr;
    public int band;
    public Vector3 scaleA = new Vector3(1.0f, 1.0f, 1.0f);
    public Vector3 scaleB = new Vector3(1.0f, 10.0f, 1.0f);
    public float scaleRatio = 1.15f;

    // Use this for initialization
    void Start()
    {
        if (ap == null)
        {
            //You can manually set it. But if not - script will take first found on scene.
            ap = GameObject.FindObjectOfType<AudioPeer>();
        }
        _tr = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        _tr.localScale = Vector3.Lerp(scaleA, scaleB, ap._audioBand[band]);
    }



}
