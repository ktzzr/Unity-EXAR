Unity3D iOS/Android/Standalone plugin

Sound Visualizer - Color Waves

---------------------------------------------------------------------------
Description: 
This plugin works on iOS, Android and Standalone (fully tested)
===
Features:
- Get data from playing AudioSource and split it on 8 accurate channels.  
  Channel diapasones depend on <b>hearing</b> deapasons. Where 0 - bass 
  and 8 - high frequencies. You can always change it on your own.
- Four ways to access audio data:
  1) RAW data from channel; 
  2) Smoothed raw data (to avoid flickering);
  3) Normalized data from channel (0..1);
  4) Buffered normalized data.
- Falling maximum values for better data normalization.
===
- Color wave visualisation as example
- Generating waves with Pelin Noise
- Editable size, scale, base speed and color gradient
- Current wave speed and color depend on playing audio data
- Full sources included
- Ready-to-go asset. Easily deployable in existing project.
- Developed with love <3

Full example of using included in package as Demo scene.

Check *.cs files for more info.

Support: kv@siberian.pro

---------------------------------------------------------------------------
Version Changes:
1.0:
    - Initial version.
2.0
    - Added	Overall Scale
    - Added Offset
    - Added support of multiple AudioSources
    - Flag for scaling prefab witout moving
    
    - Fixed bug with moving by Y-coord 


Troubleshooting
===============
+Before work with included Demo doublecheck your audiodevice. It should be turned on.
Check you hear sound from your dynamics. 

+Dont Mute game mode. And UNcheck "Mute" property of AudioSourse on AudioPeer game object.

+Be sure you got valid audio file in AudioPeer->AudioSource.AudioClip


