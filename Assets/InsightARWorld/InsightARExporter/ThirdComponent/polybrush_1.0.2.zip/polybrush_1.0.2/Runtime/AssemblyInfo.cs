﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Polybrush.Tests")]
[assembly: InternalsVisibleTo("Unity.Polybrush.Tests.Framework")]
[assembly: InternalsVisibleTo("Unity.Polybrush.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Polybrush.Editor")]