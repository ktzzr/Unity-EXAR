FHelpers is folder with classes providing helpful static methods.
They're not extension methods to avoid duplicates and conflicts with custom user extension methods.