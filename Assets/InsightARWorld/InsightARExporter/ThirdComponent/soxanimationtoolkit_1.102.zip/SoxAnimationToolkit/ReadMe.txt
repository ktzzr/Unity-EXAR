More information is available in the online documentation. Copy the following address to the clipboard and enter it in the address bar of Internet Explorer.

https://docs.google.com/document/d/1UF9raQHnErz8unyR-_h8UUuk8ePuV58T99DTorp-5F0/edit?usp=sharing